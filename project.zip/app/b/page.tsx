"use client";

import { App } from '../../src/App';

export default function VariantB() {
  return <App variant="b" />;
}
